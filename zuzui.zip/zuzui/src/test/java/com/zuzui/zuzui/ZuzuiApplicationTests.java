package com.zuzui.zuzui;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZuzuiApplicationTests {

	@Test
	void contextLoads() {
	}

}
